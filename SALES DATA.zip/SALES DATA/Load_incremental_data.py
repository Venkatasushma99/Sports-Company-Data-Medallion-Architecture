# Databricks notebook source
# MAGIC %md
# MAGIC Import required libraries

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pandas as pd
from io import BytesIO

# COMMAND ----------

# MAGIC %md
# MAGIC Connect to blob container using sas url

# COMMAND ----------

from azure.storage.blob import ContainerClient

container_sas_url = "https://salesblobstorage.blob.core.windows.net/salescontainer?<SAS Token>"

folder_name = "landing/"

container_client = ContainerClient.from_container_url(container_sas_url)

blobs = list(container_client.list_blobs(name_starts_with=folder_name))

csv_blobs = [blob for blob in blobs if blob.name.endswith(".csv")]

print(f"CSV files found: {len(csv_blobs)}")

# COMMAND ----------

pdf_list = []

for blob in csv_blobs:
    print(f"Reading: {blob.name}")

    data = container_client.get_blob_client(blob.name).download_blob().readall()

    pdf = pd.read_csv(BytesIO(data))
    pdf["source_file"] = blob.name
    pdf["file_size"] = blob.size

    pdf_list.append(pdf)

final_pdf = pd.concat(pdf_list, ignore_index=True)

df_orders = spark.createDataFrame(final_pdf) \
    .withColumn("ingestion_timestamp", current_timestamp())

# COMMAND ----------

df_orders.write\
    .format("delta")\
    .option("delta.enableChangeDataFeed", "true")\
    .mode("append")\
    .saveAsTable("sales.bronze_schema.orders")

# COMMAND ----------

# MAGIC %md
# MAGIC create a stanging table in bronze for incremental data

# COMMAND ----------

df_orders.write\
    .format("delta")\
    .option("delta.enableChangeDataFeed", "true")\
    .mode("overwrite")\
    .saveAsTable("sales.bronze_schema.staging_orders")

# COMMAND ----------

# MAGIC %md
# MAGIC move files from landing to processed

# COMMAND ----------

from azure.storage.blob import ContainerClient
from urllib.parse import quote
import time

sas_token = "<SAS Token>"


container_url = f"https://salesblobstorage.blob.core.windows.net/salescontainer?{sas_token}"
container_client = ContainerClient.from_container_url(container_url)

landing_folder = "landing/"
processed_folder = "processed/"

blobs = [
    blob for blob in container_client.list_blobs(name_starts_with=landing_folder)
    if blob.name.endswith(".csv")
]

for blob in blobs:
    source_name = blob.name
    file_name = source_name.split("/")[-1]
    target_name = processed_folder + file_name

    source_blob = container_client.get_blob_client(source_name)
    target_blob = container_client.get_blob_client(target_name)

    encoded_source_name = quote(source_name)
    source_url = f"https://salesblobstorage.blob.core.windows.net/salescontainer/{encoded_source_name}?{sas_token}"

    copy = target_blob.start_copy_from_url(source_url)

    props = target_blob.get_blob_properties()
    while props.copy.status == "pending":
        time.sleep(1)
        props = target_blob.get_blob_properties()

    if props.copy.status == "success":
        source_blob.delete_blob()
        print(f"Moved: {source_name} -> {target_name}")
    else:
        print(f"Copy failed: {source_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC silver layering

# COMMAND ----------

df=spark.sql("select * from sales.bronze_schema.staging_orders")

# COMMAND ----------

# remove the weekday from date

df=df.withColumn("order_placement_date", regexp_replace("order_placement_date",r"^[A-Za-z]+,\s*",""))


df=df.withColumn(
    "order_placement_date",
    coalesce(
        try_to_date("order_placement_date", "yyyy/MM/dd"),
        try_to_date("order_placement_date", "dd-MM-yyyy"),
        try_to_date("order_placement_date", "dd/MM/yyyy"),
        try_to_date("order_placement_date", "MMMM dd, yyyy"),
    )
)


df=df.dropDuplicates()

df=df.withColumn("customer_id", when(col("customer_id").rlike("^[0-9]+$"),col("customer_id")).otherwise("999999").cast("string"))

df=df.filter(col("order_qty").isNotNull())

df=df.withColumn("product_id",col("product_id").cast('string'))

# COMMAND ----------

dfp=spark.sql("select * from sales.silver_schema.sd_products")

# COMMAND ----------

dfj=df.join(dfp,on="product_id",how="inner").select(df['*'],dfp["product_code"])

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if not (spark.catalog.tableExists("sales.silver_schema.sd_orders")):
    dfj.write.format("delta").option(
        "delta.enableChangeDataFeed", "true"
    ).option("mergeSchema", "true").mode("overwrite").saveAsTable("sales.silver_schema.sd_orders")
else:
    silver_delta = DeltaTable.forName(spark, "sales.silver_schema.sd_orders")
    silver_delta.alias("silver").merge(dfj.alias("bronze"), "silver.order_placement_date = bronze.order_placement_date AND silver.order_id = bronze.order_id AND silver.product_code = bronze.product_code AND silver.customer_id = bronze.customer_id").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

# COMMAND ----------

# stagging for incremental data

dfj.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .mode("overwrite") \
 .saveAsTable("sales.silver_schema.staging_orders")

# COMMAND ----------

# MAGIC %md
# MAGIC gold layering

# COMMAND ----------

spark.sql("select * from sales.silver_schema.staging_orders").show()

# COMMAND ----------

dfg=spark.sql("select order_id, order_placement_date as date, customer_id as customer_code, product_code, product_id, order_qty as sold_quantity  from sales.silver_schema.staging_orders")

# COMMAND ----------

gold_table="sales.gold_schema.sd_fact_orders"

# COMMAND ----------

if not (spark.catalog.tableExists(gold_table)):
    print("creating New Table")
    dfg.write.format("delta").option(
        "delta.enableChangeDataFeed", "true"
    ).option("mergeSchema", "true").mode("overwrite").saveAsTable(gold_table)
else:
    gold_delta = DeltaTable.forName(spark, gold_table)
    gold_delta.alias("source").merge(dfg.alias("gold"), "source.date = gold.date AND source.order_id = gold.order_id AND source.product_code = gold.product_code AND source.customer_code = gold.customer_code").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

# COMMAND ----------

dfc=spark.sql("select  order_placement_date as date  from sales.silver_schema.staging_orders")

# COMMAND ----------

inc_month_df=dfc.select(trunc("date","MM").alias("start_month")).distinct()
inc_month_df.createOrReplaceTempView("inc_month")

# COMMAND ----------

monthly_tab=spark.sql(""" select  date, product_code, customer_code, sold_quantity from sales.gold_schema.sd_fact_orders sdf
                    inner join inc_month m
                    on trunc(sdf.date,'MM')=m.start_month """)


# COMMAND ----------

monthly_tab_cal=monthly_tab.withColumn("month_start",trunc("date","MM"))\
    .groupBy(col("month_start").alias("date"),"product_code","customer_code")\
    .agg(sum("sold_quantity").alias("sold_quantity"))


# COMMAND ----------

gpd=DeltaTable.forName(spark, "sales.gold_schema.fact_orders")
gpd.alias("source").merge(monthly_tab_cal.alias("gold"), "source.date = gold.date AND source.product_code = gold.product_code AND source.customer_code = gold.customer_code").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

# COMMAND ----------

spark.sql("select * from sales.gold_schema.sd_fact_orders").count()

# COMMAND ----------

