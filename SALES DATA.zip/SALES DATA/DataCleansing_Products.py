# Databricks notebook source
# MAGIC %md
# MAGIC Datacleaning Products

# COMMAND ----------

from pyspark.sql.functions import *
from delta.tables import DeltaTable

# COMMAND ----------

df_prod=spark.sql("select * from sales.bronze_schema.products")

# COMMAND ----------

df_prod.show() 

# COMMAND ----------

# MAGIC %md
# MAGIC Remove duplicates

# COMMAND ----------

df_prod.count()

# COMMAND ----------

df_prod.distinct().count()

# COMMAND ----------

df=df_prod.dropDuplicates()

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC check distinct names
# MAGIC

# COMMAND ----------

df.select("category").distinct().show()

# COMMAND ----------

df=df.withColumn("category",initcap("category"))

# COMMAND ----------

df.select("product_name").distinct().orderBy("product_name").display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC fix protein spelling

# COMMAND ----------

df=df.withColumn("category",regexp_replace("category","(?i)Protien","Protein"))\
  .withColumn("product_name",regexp_replace("product_name","(?i)Protien","Protein"))

# COMMAND ----------

df.count()

# COMMAND ----------

dic={"Energy Bars":"Nutrition Bars",
     "Protein Bars":"Nutrition Bars",
     "Granola & Cereals":"Breakfast Foods",
     "Recovery Dairy":"Dairy & Recovery",
    "Healthy Snacks" :"Healthy Snacks",
     "Electrolyte Mix":"Hydration & Electrolytes"}

# COMMAND ----------

dw=spark.createDataFrame(
    [(k,v) for k,v in dic.items()],
    ["category","division"]
)

# COMMAND ----------

df=df.join(dw,df.category==dw.category,"left")


# COMMAND ----------

df=df.withColumn("variant",regexp_extract(col("product_name"),r"\((.*?)\)",1))

# COMMAND ----------

df.select("product_id").distinct().display()

# COMMAND ----------

df=df.withColumn("product_id",
              when(col("product_id").cast("string").rlike("^[0-9]+$"),col("product_id").cast("string"))
              .otherwise(lit(999999).cast("string")))

# COMMAND ----------

df=df.withColumn("product_code",sha2(col("product_name").cast("string"),256))

# COMMAND ----------

df=df.withColumnRenamed("product_name","product")

# COMMAND ----------

df.dropDuplicates().show()

# COMMAND ----------

df.write\
    .format("delta")\
    .option("delta.enableChangeDataFeed","true")\
    .option("mergeSchema","true")\
    .mode("overwrite")\
    .saveAsTable("sales.silver_schema.sd_products")

# COMMAND ----------

print(df.columns)

# COMMAND ----------

df = df.toDF(
    "product",
    "product_id",
    "category",
    "source_file",
    "read_timestamp",
    "category_dup",
    "division",
    "variant",
    "product_code"
)

df = df.drop("category_dup")

# COMMAND ----------

# MAGIC %md
# MAGIC Gold layering

# COMMAND ----------

dfg=spark.sql("select * from sales.silver_schema.sd_products")

# COMMAND ----------

dfg=dfg.select("product_code","division","category","product","variant","product_id")

# COMMAND ----------

dfg.write\
    .format("delta")\
    .option("delta.enableChangeDataFeed", "true")\
    .mode("overwrite")\
    .saveAsTable("sales.gold_schema.sd_dim_products")

# COMMAND ----------

# MAGIC %md
# MAGIC merge child and parents data

# COMMAND ----------

dt=DeltaTable.forName(spark,"sales.gold_schema.dim_products")
dfg=spark.sql("select  product_code, division, category, product, variant  from sales.gold_schema.sd_dim_products")


# COMMAND ----------

dfg.display()

# COMMAND ----------

dt.alias("target").merge(source=dfg.alias("source"), condition="target.product_code = source.product_code")\
.whenMatchedUpdate(    set={
        "division": "source.division",
        "category": "source.category",
        "product": "source.product",
        "variant": "source.variant"
    })\
.whenNotMatchedInsert(    values={
        "product_code": "source.product_code",
        "division": "source.division",
        "category": "source.category",
        "product": "source.product",
        "variant": "source.variant"
    }).execute()

# COMMAND ----------

