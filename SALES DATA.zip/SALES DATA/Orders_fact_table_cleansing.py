# Databricks notebook source
from azure.storage.blob import ContainerClient

container_sas_url = "https://salesblobstorage.blob.core.windows.net/salescontainer?<SAS Token>"

container_client = ContainerClient.from_container_url(container_sas_url)

blobs = container_client.list_blobs(name_starts_with="landing/")

for blob in blobs:
    print(blob.name)

# COMMAND ----------

df = spark.read.options(header=True, inferSchema=True).csv(f"{landing_path}/*.csv").withColumn("read_timestamp", F.current_timestamp()).select("*", "_metadata.file_name", "_metadata.file_size")

# COMMAND ----------

container_sas_url = "https://salesblobstorage.blob.core.windows.net/salescontainer?<SAS Token>"

folder_name = "landing/"

container_client = ContainerClient.from_container_url(container_sas_url)

blobs = list(container_client.list_blobs(name_starts_with=folder_name))

csv_blobs = [blob for blob in blobs if blob.name.endswith(".csv")]

print(f"CSV files found: {len(csv_blobs)}")

# COMMAND ----------

pdf_list = []

for blob in csv_blobs:
    print(f"Reading: {blob.name}")

    data = container_client.get_blob_client(blob.name).download_blob().readall()

    pdf = pd.read_csv(BytesIO(data))
    pdf["source_file"] = blob.name
    pdf["file_size"] = blob.size

    pdf_list.append(pdf)

final_pdf = pd.concat(pdf_list, ignore_index=True)

df_orders = spark.createDataFrame(final_pdf) \
    .withColumn("ingestion_timestamp", current_timestamp())

# COMMAND ----------



df_orders.write \
    .format("delta") \
    .mode("append") \
    .option("mergeSchema", "true") \
    .saveAsTable("sales.bronze_schema.orders")

# COMMAND ----------

spark.sql("select * from sales.bronze_schema.orders").count()

# COMMAND ----------

from azure.storage.blob import ContainerClient
import time

sas_token = "<SAS Token>"

container_sas_url = f"https://salesblobstorage.blob.core.windows.net/salescontainer?{sas_token}"

container_client = ContainerClient.from_container_url(container_sas_url)

landing_folder = "landing/"
processed_folder = "processed/"

blobs = [
    blob for blob in container_client.list_blobs(name_starts_with=landing_folder)
    if blob.name.endswith(".csv")
]

for blob in blobs:
    source_name = blob.name
    file_name = source_name.split("/")[-1]
    target_name = processed_folder + file_name

    source_blob = container_client.get_blob_client(source_name)
    target_blob = container_client.get_blob_client(target_name)

    copy_operation = target_blob.start_copy_from_url(source_blob.url + "?" + sas_token)

    props = target_blob.get_blob_properties()
    while props.copy.status == "pending":
        time.sleep(1)
        props = target_blob.get_blob_properties()

    if props.copy.status == "success":
        source_blob.delete_blob()
        print(f"Moved: {source_name} -> {target_name}")
    else:
        print(f"Copy failed: {source_name}")

# COMMAND ----------

from azure.storage.blob import ContainerClient
from urllib.parse import quote
import time

sas_token = "<SAS Token>"


container_url = f"https://salesblobstorage.blob.core.windows.net/salescontainer?{sas_token}"
container_client = ContainerClient.from_container_url(container_url)

landing_folder = "landing/"
processed_folder = "processed/"

blobs = [
    blob for blob in container_client.list_blobs(name_starts_with=landing_folder)
    if blob.name.endswith(".csv")
]

for blob in blobs:
    source_name = blob.name
    file_name = source_name.split("/")[-1]
    target_name = processed_folder + file_name

    source_blob = container_client.get_blob_client(source_name)
    target_blob = container_client.get_blob_client(target_name)

    encoded_source_name = quote(source_name)
    source_url = f"https://salesblobstorage.blob.core.windows.net/salescontainer/{encoded_source_name}?{sas_token}"

    copy = target_blob.start_copy_from_url(source_url)

    props = target_blob.get_blob_properties()
    while props.copy.status == "pending":
        time.sleep(1)
        props = target_blob.get_blob_properties()

    if props.copy.status == "success":
        source_blob.delete_blob()
        print(f"Moved: {source_name} -> {target_name}")
    else:
        print(f"Copy failed: {source_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC silver layering

# COMMAND ----------

df=spark.sql("select * from sales.bronze_schema.orders")

# COMMAND ----------

df.show(10)

# COMMAND ----------

# MAGIC %md
# MAGIC cleaning placement date

# COMMAND ----------

# remove the weekday from date

df=df.withColumn("order_placement_date", regexp_replace("order_placement_date",r"^[A-Za-z]+,\s*",""))


# COMMAND ----------

df=df.withColumn(
    "order_placement_date",
    coalesce(
        try_to_date("order_placement_date", "yyyy/MM/dd"),
        try_to_date("order_placement_date", "dd-MM-yyyy"),
        try_to_date("order_placement_date", "dd/MM/yyyy"),
        try_to_date("order_placement_date", "MMMM dd, yyyy"),
    )
)


# COMMAND ----------

# MAGIC %md
# MAGIC count duplicates
# MAGIC

# COMMAND ----------

df.distinct().count()

# COMMAND ----------

df.count()

# COMMAND ----------

df=df.dropDuplicates()

# COMMAND ----------

df.select("customer_id").distinct().display()

# COMMAND ----------

dff=df.withColumn("customer_id", when(col("customer_id").rlike("^[0-9]+$"),col("customer_id")).otherwise("999999").cast("string"))

# COMMAND ----------

dff.select("order_qty").distinct().display()

# COMMAND ----------

dff=dff.filter(col("order_qty").isNotNull())

# COMMAND ----------

dff.select("order_qty").distinct().count()

# COMMAND ----------

dff=dff.withColumn("product_id",col("product_id").cast('string'))

# COMMAND ----------

# MAGIC %md
# MAGIC import products data

# COMMAND ----------

dfp=spark.sql("select * from sales.silver_schema.sd_products")

# COMMAND ----------

dfj=dff.join(dfp,on="product_id",how="inner").select(dff['*'],dfp["product_code"])

# COMMAND ----------

if not (spark.catalog.tableExists("sales.silver_schema.sd_orders")):
    dfj.write.format("delta").option(
        "delta.enableChangeDataFeed", "true"
    ).option("mergeSchema", "true").mode("overwrite").saveAsTable("sales.silver_schema.sd_orders")
else:
    silver_delta = DeltaTable.forName(spark, "sales.silver_schema.sd_orders")
    silver_delta.alias("silver").merge(dfj.alias("bronze"), "silver.order_placement_date = bronze.order_placement_date AND silver.order_id = bronze.order_id AND silver.product_code = bronze.product_code AND silver.customer_id = bronze.customer_id").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

# COMMAND ----------

# MAGIC %md
# MAGIC gold layering

# COMMAND ----------

dfg=spark.sql("select order_id, order_placement_date as date, customer_id as customer_code, product_code, product_id, order_qty as sold_quantity  from sales.silver_schema.sd_orders")

# COMMAND ----------

dfg.write.format("delta")\
    .option("delta.enableChangeDataFeed", "true")\
        .option("overwriteSchema", "true").option("mergeSchema", "true").mode("overwrite").saveAsTable("sales.gold_schema.sd_fact_orders")

# COMMAND ----------

spark.sql("select count(*) from sales.gold_schema.sd_fact_orders").display()

# COMMAND ----------

if not (spark.catalog.tableExists("sales.gold_schema.sd_fact_orders")):
    print("creating New Table")
    dfg.write.format("delta").option(
        "delta.enableChangeDataFeed", "true"
    ).option("mergeSchema", "true").mode("overwrite").saveAsTable("sales.gold_schema.sd_fact_orders")
else:
    gold_delta = DeltaTable.forName(spark, "sales.gold_schema.sd_fact_orders")
    gold_delta.alias("source").merge(dfg.alias("gold"), "source.date = gold.date AND source.order_id = gold.order_id AND source.product_code = gold.product_code AND source.customer_code = gold.customer_code").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

# COMMAND ----------

# MAGIC %md
# MAGIC merging parent and child

# COMMAND ----------

dfc=spark.sql("select date, product_code, customer_code, sold_quantity from sales.gold_schema.sd_fact_orders")

# COMMAND ----------

dfc.show()

# COMMAND ----------

dfc.count()

# COMMAND ----------

dfpa=spark.sql("select * from sales.gold_schema.fact_orders")

# COMMAND ----------

dfm=dfc.withColumn("month_start",trunc("date","MM"))

# COMMAND ----------

dfmg=dfm.groupBy(col("month_start").alias("date"),"product_code","customer_code")\
    .agg(sum("sold_quantity").alias("sold_quantity"))

# COMMAND ----------

dfm.count()

# COMMAND ----------

gpd=DeltaTable.forName(spark, "sales.gold_schema.fact_orders")
gpd.alias("source").merge(dfm.alias("gold"), "source.date = gold.date AND source.product_code = gold.product_code AND source.customer_code = gold.customer_code").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

# COMMAND ----------

dfpa.printSchema()

# COMMAND ----------

dfm.printSchema()

# COMMAND ----------

dfpa=dfpa.withColumn("customer_code",col("customer_code").cast('string'))

# COMMAND ----------

dfpa.write\
 .format("delta") \
 .mode("overwrite") \
 .option("overwriteSchema","true")\
 .saveAsTable("sales.gold_schema.sd_fact_orders")

# COMMAND ----------

