# Databricks notebook source
# MAGIC %md
# MAGIC #Initial Setup 
# MAGIC ### Creating Catalogs, Schemas, load data 

# COMMAND ----------

# DBTITLE 1,Create a catalog Sales
# MAGIC %sql
# MAGIC CREATE CATALOG IF NOT EXISTS SALES

# COMMAND ----------

# DBTITLE 1,Define the catalog you are using
# MAGIC %sql
# MAGIC USE CATALOG SALES
# MAGIC     
# MAGIC

# COMMAND ----------

# DBTITLE 1,Create schemas ( Bronze, Silver, Gold)
# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS BRONZE_SCHEMA;
# MAGIC CREATE SCHEMA IF NOT EXISTS SILVER_SCHEMA;
# MAGIC CREATE SCHEMA IF NOT EXISTS GOLD_SCHEMA;

# COMMAND ----------

# MAGIC %md
# MAGIC # Create date table 

# COMMAND ----------

# DBTITLE 1,Defining the date table ranges of project
start_date= '2026-07-01'
end_date='2026-12-31'

# COMMAND ----------

df=spark.createDataFrame([['2026-07-01','2026-12-31']],['start_date','end_date'])


# COMMAND ----------

# DBTITLE 1,Import necessary functions, modules
from pyspark.sql.functions import *
from pyspark.sql.types import *




# COMMAND ----------

df=df.withColumn("Date",sequence(to_date(col("start_date")),to_date(col("end_date"))))

# COMMAND ----------

df=df.withColumn("Project_Dates",explode(col("Date")))

# COMMAND ----------

df=df.select("Project_Dates")

# COMMAND ----------

df.show()

# COMMAND ----------

df= df.withColumn("date_Key", date_format(col("Project_Dates"), "yyyyMM"))\
  .withColumn("date", date_format(col("Project_Dates"), "yyyy-MM-dd"))\
  .withColumn("day", date_format(col("Project_Dates"), "dd"))\
  .withColumn("month_name", date_format(col("Project_Dates"), "MMMM"))\
  .withColumn("month_short_name", date_format(col("Project_Dates"), "MMM"))\
  .withColumn("quarter", date_format(col("Project_Dates"), "Q"))\
  .withColumn("month", date_format(col("Project_Dates"), "MM"))\
  .withColumn("year", date_format(col("Project_Dates"), "yyyy"))\
  .withColumn("day_of_week", date_format(col("Project_Dates"), "E"))\
  .withColumn("day_of_year", date_format(col("Project_Dates"), "DDD"))

# COMMAND ----------

df.write.mode("overwrite").format("delta").saveAsTable("sales.gold_schema.dim_date")

# COMMAND ----------

# MAGIC %md
# MAGIC Establish connection between the Azure blob and the databricks ( for a specific file)

# COMMAND ----------

sas_url = "<SAS Token>"

dfs = spark.read.csv(
    sas_url,
    header=True,
    inferSchema=True
)



# COMMAND ----------

import pandas as pd

pdf = pd.read_csv(sas_url)

dfs = spark.createDataFrame(pdf)

dfs.show()

# COMMAND ----------

