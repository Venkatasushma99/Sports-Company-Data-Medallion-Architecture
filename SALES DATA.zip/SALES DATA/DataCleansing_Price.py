# Databricks notebook source
# MAGIC %md
# MAGIC Datacleansing Price dataset

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *


# COMMAND ----------

# MAGIC %md 
# MAGIC silver layering

# COMMAND ----------

df=spark.sql("select * from sales.bronze_schema.gross_price")

# COMMAND ----------

df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC cleansing month field

# COMMAND ----------

df.select("month").distinct().show()

# COMMAND ----------

df=df.withColumn("month",
              date_format(
                  coalesce(
                      try_to_date(col("month"),"yyyy/MM/dd"),
                      try_to_date(col("month"),'dd/MM/yyyy'),
                      try_to_date(col("month"),"yyyy-MM-dd"),
                      try_to_date(col("month"),"dd-MM-yyyy")
                  ), "dd-MM-yyyy"
              ))

# COMMAND ----------

df.distinct().count()

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC cleaning gross_price

# COMMAND ----------

df.select(col("gross_price")).distinct().show()

# COMMAND ----------

df=df.withColumn("gross_price",
              when (col("gross_price").rlike(r"^-?\d+(\.\d+)?$"), abs(col("gross_price").cast("double"))).otherwise(0.0))

# COMMAND ----------

df_p=spark.sql("select * from sales.silver_schema.sd_products")

# COMMAND ----------

df_p.show()

# COMMAND ----------

dfj=df.join(df_p.select("product_code"),df.product_id==df_p.product_id,"inner")


# COMMAND ----------

dfj.show()

# COMMAND ----------

dfj.write\
   .format("delta")\
   .option("delta.enableChangeDataFeed","true")\
    .option("mergeSchema","true")\
    .option("overwriteSchema","true")\
   .mode("overwrite")\
   .saveAsTable("sales.silver_schema.sd_dim_price")
       

# COMMAND ----------

# MAGIC %md
# MAGIC gold layering

# COMMAND ----------

df=dfj.select("product_code","month","gross_price")

# COMMAND ----------

df.show()

# COMMAND ----------

df.write\
   .format("delta")\
   .option("delta.enableChangeDataFeed","true")\
       .option("overwriteSchema","true")\
   .mode("overwrite")\
   .saveAsTable("sales.gold_schema.sd_dim_price")
       

# COMMAND ----------

# MAGIC %md

# COMMAND ----------

# MAGIC %md
# MAGIC merge with parent data

# COMMAND ----------

dfp=spark.sql("select * from sales.gold_schema.dim_gross_price")

# COMMAND ----------

dfp.show()

# COMMAND ----------

df=spark.sql("select * from sales.gold_schema.sd_dim_price")

# COMMAND ----------

df.show()

# COMMAND ----------

dfw=df.withColumn("year",year(to_date(col("month"),"dd-MM-yyyy")))

# COMMAND ----------

from pyspark.sql.window import *

# COMMAND ----------

dfa=dfw.groupBy("year","product_code").agg(sum("gross_price"))

# COMMAND ----------

dfa=dfa.withColumnRenamed("sum(gross_price)","price_inr")

# COMMAND ----------

dfw.select("gross_price","product_code").filter("product_code='062f5574bbdf4386b2c7c6075483b417b4a00b172fcba919dbba7dae1b774379'")\
    .agg(sum("gross_price")).show()

# COMMAND ----------

delta_table = DeltaTable.forName(spark, "sales.gold_schema.dim_gross_price")


delta_table.alias("target").merge(
    source=dfa.alias("source"),
    condition="target.product_code = source.product_code"
).whenMatchedUpdate(
    set={
        "price_inr": "source.price_inr",
        "year": "source.year"
    }
).whenNotMatchedInsert(
    values={
        "product_code": "source.product_code",
        "price_inr": "source.price_inr",
        "year": "source.year"
    }
).execute()

# COMMAND ----------

