# Databricks notebook source
# MAGIC %md
# MAGIC # Establishing connection between the azure blob container  and the databricks 

# COMMAND ----------

sas_url = "https://salesblobstorage.blob.core.windows.net/salescontainer?<SAS Token>"

dfs1 = spark.read.csv(
    sas_url,
    header=True,
    inferSchema=True
)



# COMMAND ----------

import pandas as pd

pdf = pd.read_csv(sas_url)

dfs = spark.createDataFrame(pdf)

dfs.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Establish connection between Blob and Databricks

# COMMAND ----------

from azure.storage.blob import ContainerClient

container_sas_url = "https://salesblobstorage.blob.core.windows.net/salescontainer?<SAS Token>"

container_client = ContainerClient.from_container_url(container_sas_url)

blobs = container_client.list_blobs(name_starts_with="SportsData/")

for blob in blobs:
    print(blob.name)

# COMMAND ----------

import pandas as pd
from io import BytesIO

pdf_list = []

for blob in blobs:
    if blob.name.endswith(".csv"):
        data = container_client.get_blob_client(blob.name).download_blob().readall()
        pdf = pd.read_csv(BytesIO(data))
        pdf["file_name"] = blob.name
        pdf["file_size"] = blob.size
        pdf_list.append(pdf)

# COMMAND ----------

# MAGIC %md
# MAGIC Load the Blob data to bronze layer

# COMMAND ----------

from io import BytesIO
import pandas as pd
from pyspark.sql.functions import *

blobs = container_client.list_blobs(name_starts_with="SportsData/")

for blob in blobs:
    if blob.name.endswith(".csv"):

        print(f"Processing {blob.name}")

        # Download the file
        data = container_client.get_blob_client(blob.name).download_blob().readall()

        # Read into pandas
        pdf = pd.read_csv(BytesIO(data))

        # Convert to Spark
        df = spark.createDataFrame(pdf)

        # Add metadata columns
        df = (
            df.withColumn("source_file", lit(blob.name))
              .withColumn("read_timestamp", current_timestamp())
        )

        # Extract table name from file name
        table_name = blob.name.split("/")[-1].replace(".csv", "")

        # Write to Bronze
        df.write \
            .format("delta") \
            .mode("overwrite") \
            .option("overwriteSchema", "true") \
            .saveAsTable(f"sales.bronze_schema.{table_name}")

        print(f"Written to bronze.{table_name}")

# COMMAND ----------

