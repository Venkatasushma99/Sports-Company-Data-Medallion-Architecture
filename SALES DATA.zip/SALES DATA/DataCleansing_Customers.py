# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC #Data Cleaning - Customers
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Silver layering

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Read customers data from Bronze
df=spark.sql("select * from sales.bronze_schema.customers")

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df=df.select("customer_id","city","customer_name")

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC cleaning city name

# COMMAND ----------

spark.sql("select distinct city from sales.bronze_schema.customers order by city ").show()

# COMMAND ----------

dis={'Bengalore':'Bengalore',
     'Bengaluru':'Bengalore',
     'Bengaluruu':'Bengalore',
     'Hyderabad':'Hyderabad',
     'Hyderabadd':'Hyderabad',
     'Hyderbad':'Hyderabad',
     'New Delhi':'New Delhi',
     'NewDelhee':'New Delhi',
     'NewDelhi':'New Delhi',
     'NewDheli':'New Delhi'}

# COMMAND ----------

df=df.replace(dis,subset=['city'])

# COMMAND ----------

df.select("city").distinct().show()

# COMMAND ----------

# MAGIC %md
# MAGIC cleansing the customer_id

# COMMAND ----------

df.select("customer_id","city","customer_name").distinct().display()

# COMMAND ----------

df=df.dropDuplicates(["customer_id"])

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC cleaning customer names
# MAGIC

# COMMAND ----------

df.select("customer_name").distinct()\
    .orderBy("customer_name").show()

# COMMAND ----------

from pyspark.sql.functions import initcap,trim

# COMMAND ----------

df=df.withColumn("customer_name",initcap(trim("customer_name")))

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

df=df.withColumn("market",lit("India"))\
    .withColumn("Platform",lit("Sports Bar"))\
    .withColumn("Channel",lit("Acquisition"))

# COMMAND ----------

df.display()

# COMMAND ----------

df.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .option("mergeSchema", "true") \
 .mode("overwrite") \
 .saveAsTable(f"sales.silver_schema.sd_customers")

# COMMAND ----------

rn=spark.sql("select * from sales.gold_schema.sd_dim_customers")

# COMMAND ----------

pc=pc.withColumn("customer_code",col("customer_code").cast("string"))

# COMMAND ----------

pc=md.withColumn("customer_id",col("customer_id").cast("string"))

# COMMAND ----------

pc.write\
 .format("delta") \
 .mode("overwrite") \
 .option("overwriteSchema","true")\
 .saveAsTable("sales.gold_schema.dim_customers")

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold layering

# COMMAND ----------

df.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .mode("overwrite") \
 .saveAsTable("sales.gold_schema.sd_dim_customers")

# COMMAND ----------

# MAGIC %md
# MAGIC mergeing parents data with child data

# COMMAND ----------

pc=spark.sql("select * from sales.gold_schema.sd_dim_customers")

# COMMAND ----------

pc=pc.withColumn("customer_id",col("customer_id").cast("string"))

# COMMAND ----------

pc.write\
 .format("delta") \
 .mode("overwrite") \
 .option("overwriteSchema","true")\
 .saveAsTable("sales.gold_schema.dim_customers")

# COMMAND ----------

rd=spark.sql("select * from sales.gold_schema.sd_dim_customers")

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

deltatable= DeltaTable.forName(spark,"sales.gold_schema.dim_customers")

# COMMAND ----------

rd.printSchema()

# COMMAND ----------

deltatable.alias("target").merge(
    source=rd.alias("source"),
    condition="target.customer_code = source.customer_id"
).whenMatchedUpdate(set={
    "customer_code": "source.customer_id",
    "customer": "source.customer_name",
    "market": "source.market",
    "platform": "source.Platform",
    "channel": "source.Channel"
}).whenNotMatchedInsert(values={
    "customer_code": "source.customer_id",
    "customer": "source.customer_name",
    "market": "source.market",
    "platform": "source.Platform",
    "channel": "source.Channel"
}).execute()

# COMMAND ----------

